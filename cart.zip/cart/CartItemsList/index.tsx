import React, { useEffect } from "react";
import ProtectionPlan from "../ProtectionCart/index";
import AmcInstaCart from "../AmcInstaCart/index";
import HomeCareCart from "../HomeCareCart/index";
import router from "next/router";

interface Props {
  cart?: any;
  increment?: any;
  decrement?: any;
  removeCartItem?: any;
}
const CartItems = (props: Props) => {

  const checkCartItemListType = () => {
    if (props.cart.type == "insta-repair" || props.cart.type == "amc") {
      return (
        <AmcInstaCart
          cart={props.cart}
          decrement={props.decrement}
          increment={props.increment}
          removeCartItem={props.removeCartItem}
        />
      );
    } else if (props.cart.type == "homecare") {
      return (
        <HomeCareCart cart={props.cart} removeCartItem={props.removeCartItem} />
      );
    } else {
      return (
        <ProtectionPlan
          cart={props.cart}
          removeCartItem={props.removeCartItem}
        />
      );
    }
  };
  return <div>{checkCartItemListType()}</div>;
};

export default CartItems;
