import React from "react";
import styles from "../../../../style/cart.module.scss";
import { formatNumber, formatDate } from "../../../../../utils";
import DeleteIcon from "@material-ui/icons/Delete";
import CreateIcon from "@material-ui/icons/Create";
import { ListItem } from "@material-ui/core";
import Config from "../../../../../config";

interface Props {
  item?: any;
  decrement?: any;
  increment?: any;
  removeCartItem?: any;
}

const CartItem = (props: Props) => {
  return (
    <div>
      <div className={styles.productContainer}>
        <div
          className={`${props.item.group == "insta-repair"? styles.productSummaryInsta: styles.productSummaryAmc}`}>
          <div className={styles.col_1}>
            <div className={styles.col_1_details}>
              <div className={styles.productImg}>
                <img src={props.item.image} alt="repair" />
              </div>
              <div>
                <h6>
                  {props.item.display_title}{" "}
                  {props.item.group == "insta-repair"
                    ? ""
                    : `-${props.item.duration}`}
                </h6>
                <span>{props.item.category}</span>
              </div>
            </div>
            {props.item.group == "insta-repair" ? (
              <div className={styles.column}>
                <div className={styles.col_2}>
                  <span
                    className={styles.count}
                    onClick={(e) => props.decrement(props.item)}
                  >
                    -
                  </span>
                  <span>{props.item.quantity}</span>
                  <span
                    className={styles.count}
                    onClick={() => props.increment(props.item)}
                  >
                    +
                  </span>
                </div>
              </div>
            ) : (
              <div className={styles.column}>
                <p className={styles.qty}>Qty1</p>
                <div className={styles.col_2}>
                  <div>
                    Plan start :
                    <p>
                      {formatDate(
                        props.item.preferred_plan_start_date,
                        Config.HUMAN_READABLE_DATE_FORMAT
                      )}
                      <CreateIcon className={styles.createIcon} />
                      Edit
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
          <div className={styles.col_3}>
            <span>
              &#8377;{" "}
              {formatNumber(
                props.item.quantity * parseInt(props.item.unit_price)
              ).replace(
                formatNumber(
                  props.item.quantity * parseInt(props.item.unit_price)
                )[0],
                ""
              )}
            </span>
            <DeleteIcon
              className={styles.deleteIcon}
              onClick={() => props.removeCartItem(props.item)}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartItem;
