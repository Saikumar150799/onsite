import modalStyles from "../../../../styles/modules/components/device.module.scss";
import React, { Fragment } from "react";
import UIModal from "../..../../../../../components/common/ui-components/surface/UIModal";
import { serviceModalToggle } from "../../../../redux/actions/cartActions";
import Button from '../../../../components/common/ui-components/input/Button';
// import '../../../../components/common/ui-components/input/Button'
interface Props {
  cart?: any;
  serviceModalToggle?: any;
}
const ServiceablePopUp = (props: Props) => {


  const toggleServiceModal = (show) => {
    props.serviceModalToggle(show);

  };

  const getServiceableMessage = () => {
    if (props.cart.items.find(i => i.serviceable === false)) {
        let nonServiceableTypes = ""
        props.cart.items.forEach((item: any) => {
          if (!item.serviceable) {
            if (nonServiceableTypes.indexOf(item.display_title) < 0) {
              nonServiceableTypes += nonServiceableTypes == "" ? item.display_title : `, ${item.display_title}`
            }
          }
        })
        return `We are yet to open up ${nonServiceableTypes} services in your locality.`
      }
      else {
        return 'We are yet to open up services in your locality.'
      }
  };
  return (
    <div>
      <UIModal
        isOpen={true}
        onClick={() => {
          toggleServiceModal(false);
        }}
      >
        <Fragment>
          <div className={modalStyles.cart_alert}>
            <h5 className={modalStyles.cart_alert__title}>
              Sorry, we will not be able to service your request at this time.
            </h5>
            <div className={modalStyles.cart_alert__text}>
              {props.cart.type == "protection-plan"
                ? getServiceableMessage()
                : "Our team is working at maximum capacity in your area right now."}
              <br />
              We apologize for the inconvenience and we hope that we will be
              able to serve you soon.
            </div>
          </div>
          <div className={modalStyles.selection_actions_common}>
            <Button
                onClick={() => { toggleServiceModal(false) }}
                text="OK"
              />
          </div>
        </Fragment>
      </UIModal>
    </div>
  );
};

export default ServiceablePopUp;
