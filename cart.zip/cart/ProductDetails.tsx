import React, { useState, useEffect } from "react";
import styles from "../../../style/cart.module.scss";
import CartItemsList from "../cart/CartItemsList/index";
import SummaryList from "./SummaryList/index";

interface Props {
  setOtpVerificationAccordion?: any;
  cart?: any;
  removeItem?: any;
  patchCartItem?: any;
  removeItemInsta?: any;
  applyDiscount?: any;
  removeDiscount?: any;
  toggleCartAlert?: any;
}

const ProductDetails = (props: Props) => {

  const decrement = (item) => {
    props.removeItemInsta(
      {
        application: "website",
        id: item.id,
        quantity: item.quantity,
        token_id: props.cart.token_id,
      },
      1,
      false
    );
  };

  const increment = (item) => {
    const data = {
      type: "insta-repair",
      token_id: props.cart.token_id,
      channel_name: "website",
    };
    data["quantity"] = item.quantity + 1;
    props.patchCartItem(item.id, data);
  };

  const removeCartItem = (item) => {
    props.removeItem(
      {
        application: "website",
        ...item,
        token_id: props.cart.token_id,
        remove: true,
      },
      item.quantity,
      false
    );
  };

  return (
    <>
      <div className={`${styles.ProductDetails}`}>
        <div className={`${styles.OrderSummary}`}>
          <div className={styles.colName}>
            <span>Product Name</span>
            <span>
              {props.cart.type == "homecare" ? "Duration" : "Quantity"}
            </span>
            <span>Amount</span>
          </div>

          <CartItemsList
            cart={props.cart}
            increment={increment}
            decrement={decrement}
            removeCartItem={removeCartItem}
          />

          <div className={styles.cartSummaryBottomActionContainer}>
            <SummaryList
              cart={props.cart}
              setOtpVerificationAccordion={props.setOtpVerificationAccordion}
              removeDiscount={props.removeDiscount}
              applyDiscount={props.applyDiscount}
            />
          </div>
        </div>
      </div>
    </>
  );
};
export default ProductDetails;
