import React from "react";
import styles from "../../../../style/cart.module.scss";
import { formatNumber } from "../../../../../utils";
import DeleteIcon from "@material-ui/icons/Delete";

interface Props {
  cart?: any;
  removeCartItem?: any;
}
const HomeCareCart = (props: Props) => {
  return (
    <>
      {props.cart.items.map((item) => {
        console.log("itititt",item)
        return (
          <div className={styles.productContainer}>
            <div className={styles.productSummaryInsta}>
              <div className={styles.col_1}>
                <div className={styles.col_1_details}>
                  <div style={{'marginRight':'20px'}}>
                    <img src={item.image} alt="repair" />
                  </div>
                  <div className={styles.extended_warrenty}>
                    <h6>
                      {`${item.category} - ${item.duration}`}
                      <p className={styles.qty}> x {item.quantity}</p>
                    </h6>
                  </div>
                </div>
                <div className={styles.column}>
                  <div className={styles.col_2}>
                    <p className={styles.quantity}>{item.duration}</p>
                  </div>
                </div>
              </div>
              <div className={styles.col_3}>
                <span>
                  &#8377;{" "}
                  {formatNumber(
                    item.quantity * parseInt(item.unit_price)
                  ).replace(
                    formatNumber(item.quantity * parseInt(item.unit_price))[0],
                    ""
                  )}
                </span>
                <DeleteIcon
                  className={styles.deleteIcon}
                  onClick={() => props.removeCartItem( item)}
                />
              </div>
            </div>
          </div>
        );
      })}
    </>
  );
};

export default HomeCareCart;
