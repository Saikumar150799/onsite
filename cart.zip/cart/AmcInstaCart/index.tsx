import React from "react";
import SummaryListInsta from "./SummaryListInsta";
import SummaryListAmc from "./SummaryListAmc";
// import SummaryListInsta from "./SummaryListInsta";
import CartItem from "../CartItemsList/CartItem";
interface Props {
  cart?: any;
  decrement?: any;
  increment?: any;
  removeCartItem?: any;
}

const AmcInstaCart = (props: Props) => {
  return (
    <div>
      {props.cart.items.map((item) => {
        return (
          <>
            {item.group == "insta-repair" ? (
              <CartItem
                item={item}
                decrement={props.decrement}
                increment={props.increment}
                removeCartItem={props.removeCartItem}
              />
            ) : (
              <CartItem item={item} removeCartItem={props.removeCartItem} />
            )}
          </>
        );
      })}
    </div>
  );
};

export default AmcInstaCart;
