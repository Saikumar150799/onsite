import React from "react";
import CartItem from "../CartItemsList/CartItem";

interface Props {
  item?: any;
  decrement?: any;
  increment?: any;
  removeCartItem?: any;
}
const SummaryListAmc = (props: Props) => {
  return (
    <div>
      <CartItem
        item={props.item}
        decrement={props.decrement}
        increment={props.increment}
        removeCartItem={props.removeCartItem}
      />
    </div>
  );
};

export default SummaryListAmc;
