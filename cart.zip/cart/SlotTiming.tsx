import React from 'react'
import styles from "../../../style/cart.module.scss";
import Calendar from 'react-calendar';
const SlotTiming = () => {
  return (
    <div className={styles.SlotTiming}>
        <span>Perferred slot 1</span>
        <div className={styles.calender}>
          <Calendar />
        </div>
    </div>
  )
}

export default SlotTiming