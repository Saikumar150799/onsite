import React, { useEffect, useState } from "react";
import styles from "../../../style/cart.module.scss";
import CheckIcon from '@material-ui/icons/Check';
import { ExpandMore } from "@material-ui/icons";
import { getPhoneCookie } from "../../../../utils/cartV2";
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@material-ui/core";

interface Props {
  title: string;
  children?: React.ReactNode;
  expanded?: boolean|undefined;
  defaultExpanded?:boolean;
  label?:string ;
  onChange?:(panel:string)=>void;
  checkIcon?:any;
  id?:any;
}




function UIAccordion(props: Props) {


  return (
    <div className={styles.accordion} id={props.id}>
      <Accordion defaultExpanded={props.defaultExpanded} expanded={props.expanded} style={{ "boxShadow": "none",}}>
        <AccordionSummary   className={`${styles.accordian_summary}`} classes={{expanded:`${styles.accordion_expanded} ${styles.accordion_content}`}} style={{'cursor':'default'}}>
          <div className={styles.accordion_title}>
            <span>{props.title}</span>
            <div style={{'display':'flex','flexDirection':'row-reverse'}}>
            {props.expanded?<ExpandMore className={styles.expand_icon}/>:<ExpandMore />}
            {props.checkIcon}
            </div>
          </div>
        </AccordionSummary>
        <AccordionDetails className={`${styles.accordionChildren}`}>{props.children}</AccordionDetails>
     </Accordion>
    </div>
  );
}

export default UIAccordion;
