import React, { useEffect, useState } from "react";
import PersonOutlineOutlined from "@material-ui/icons/PersonOutlineOutlined";
import MailOutlineOutlined from "@material-ui/icons/MailOutlineOutlined";
import LocationOnOutlined from "@material-ui/icons/LocationOnOutlined";
import styles from "../../../../styles/pages/cart.module.scss";
import CreateIcon from "@material-ui/icons/Create";
import {getCustomerCookie} from '../../../../utils/cartV2/index'
interface Props {
  fields?: any;
  city?:any;
  IsValidPersonalDetails?:any;
  isEditMode?:any;
}
const AgentPersonalDetails = (props: Props) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pincode,setPincode]=useState("")
  const [address,setAddress]=useState("")
  const [landmark,setLandmark]=useState("")

  useEffect(() => {
    props.fields.map((element) => {
      if (element.name == "name") {
        setName(element.value);
      }else if (element.name == "email") {
        setEmail(element.value);
      }else if (element.name == "pincode") {
        setPincode(element.value);
      }else if (element.name == "address") {
        setAddress(element.value);
      }else if(element.name=='landmark'){
        setLandmark(element.value)
      }

    },[]);
  });
  const editPersonalDetails =()=>{
    props.IsValidPersonalDetails()
    props.isEditMode()
  }

  // const {name,email,pincode,city,address,landmark}=JSON.parse(getCustomerCookie("customer_personal_details"))

  return (
    <div>
      {/* {console.log("<",props.fields,props.city)} */}
      <div className={`${styles.personal_detail_edit} container`} style={{padding:"0"}}>
        <div className={`${styles.edit_name_box} row`}>
          <div className={`${styles.textbox} col-6`}>
            <PersonOutlineOutlined
              style={{ fontSize: "14px" }}
              className={styles.personal_icon}
            ></PersonOutlineOutlined>
            <div className={styles.text_label}>{name}</div>
          </div>
          <div className={`${styles.edit_icon_box} col-6`}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                paddingTop: "3px",
                cursor: "pointer",
              }}
              onClick={()=>editPersonalDetails()}
            >
              <CreateIcon style={{width:"16px",'marginRight':'8px'}}/> Edit
            </div>
          </div>
        </div>
        <div className={`${styles.textbox} col-12`}>
          <MailOutlineOutlined
            style={{ fontSize: "14px" }}
            className={styles.personal_icon}
          ></MailOutlineOutlined>
          <div className={styles.text_label}>{email}</div>
        </div>
        <div className={`${styles.textbox} col-12`}>
          <LocationOnOutlined
            style={{ fontSize: "14px" }}
            className={styles.personal_icon}
          ></LocationOnOutlined>
          <div className={styles.text_label}>{`${address} ${landmark},${props.city} - ${pincode}`}</div>
        </div>
      </div>
    </div>
  );
};

export default AgentPersonalDetails;
