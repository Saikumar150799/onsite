import React, { Component } from "react";
import styles from "../../../../style/cart.module.scss";
import { formatNumber } from "../../../../../utils";
import DeleteIcon from "@material-ui/icons/Delete";
import CreateIcon from "@material-ui/icons/Create";
import { IMEI_FIELDS } from "../../../constants/Fields";
import UITextField from "../../cart/UITextFields";
import AddCircleOutlineOutlinedIcon from "@material-ui/icons/AddCircleOutlineOutlined";
import validation from "../../../../common/validation/validation";
import { checkCategoryType } from "../../../../../utils/cart/index";

interface Props {
  cart?: any;
  removeCartItem?: any;
}
export default class ProtectionCart extends Component<Props> {
  state = {
    ImeiConstant: IMEI_FIELDS,
    IMEI_error: true,
    IMEI_number: "",
    isValid_imei_number: false,
  };

  handleChange = (e) => {
    const { name, value } = e.target;
    this.setState({ IMEI_number: value });
    this.state.ImeiConstant.map((field) => {
      if (field.name === name) {
        field.value = value;
      }
      field.errorMessage = "";
    });
    this.setState({ ImeiConstant: IMEI_FIELDS });
  };

  handleBlur = (e, field) => {
    this.setState(validation(field));
    this.state.ImeiConstant.forEach((field) => {
      field.value || field.errorMessage != ""
        ? this.setState({ IMEI_error: false })
        : this.setState({ IMEI_error: true });
      field.value && field.errorMessage == ""
        ? this.setState({ isValid_imei_number: true })
        : this.setState({ isValid_imei_number: false });
    });
  };

  validate_IMEI_number = () => {};
  render() {
    return (
      <div>
        {this.props.cart.items.map((item) => {
          return (
            <>
              <div className={styles.productContainer}>
                <div className={styles.productSummaryInsta}>
                  <div className={styles.col_1}>
                    <div className={styles.col_1_details}>
                      <div>
                        <img src="" alt="repair" />
                      </div>
                      <div className={styles.extended_warrenty}>
                        <h6>
                          {`${item.display_title} - ${item.duration}`}
                          <p className={styles.qty}>
                            {" "}
                            x {item.quantity}
                          </p>
                        </h6>
                        <span>{item.category}</span>
                        <div className={styles.price}>
                          <p>Device price </p>
                          <p style={{ fontFamily: "var(--font-semi-bold)" }}>
                            &#8377;{" "}
                            {formatNumber(
                              item.device_detail.device_price
                            ).replace(
                              formatNumber(
                                item.device_detail.device_price
                              )[0],
                              ""
                            )}
                          </p>
                          <span>
                            <CreateIcon style={{ width: "16px" }} />
                            Edit
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className={styles.column}>
                      <div className={styles.col_2}>
                        <p className={styles.quantity}>
                          QTY {item.quantity}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className={styles.col_3}>
                    <span>
                      &#8377;{" "}
                      {formatNumber(
                        item.quantity *
                          parseInt(item.unit_price)
                      ).replace(
                        formatNumber(
                          item.quantity *
                            parseInt(item.unit_price)
                        )[0],
                        ""
                      )}
                    </span>
                    <DeleteIcon
                      className={styles.deleteIcon}
                      onClick={() => this.props.removeCartItem(item)}
                    />
                  </div>
                </div>
              </div>
              {checkCategoryType(item) ? (
                <div className={styles.IMEI_container}>
                  <div className={styles.IMEI_field}>
                    {IMEI_FIELDS.map((field) => {
                      return (
                        <>
                          {!this.state.isValid_imei_number ? (
                            <>
                              <UITextField
                                type={field.type}
                                onChange={this.handleChange}
                                onBlur={(e) => this.handleBlur(e, field)}
                                placeholder={field.placeholder}
                                value={field.value}
                                name={field.name}
                                field={field}
                                errorMessage={field.errorMessage}
                                autoFocus={true}
                              />
                              <p
                                className={styles.submitIMEI}
                                onClick={() => this.validate_IMEI_number()}
                              >
                                Submit
                              </p>
                            </>
                          ) : (
                            ""
                          )}
                        </>
                      );
                    })}
                  </div>
                  {this.state.IMEI_error ? (
                    <span>Dial *#06# on your phone to view IMEI number </span>
                  ) : (
                    ""
                  )}
                  {this.state.isValid_imei_number ? (
                    <div className={styles.valid_EMIE_Number}>
                      IMEI: <p>{this.state.IMEI_number}</p>
                      <p style={{ color: "#00a99d", marginLeft: "12px" }}>
                        <CreateIcon
                          style={{ width: "16px", marginRight: "7px" }}
                        />{" "}
                        Edit
                      </p>
                    </div>
                  ) : (
                    ""
                  )}
                  <p className={styles.addmore}>
                    <AddCircleOutlineOutlinedIcon
                      style={{
                        width: "20px",
                        color: "#00A99D",
                        marginRight: "8px",
                      }}
                    />
                    Add more protection for device
                  </p>
                </div>
              ) : (
                ""
              )}
            </>
          );
        })}
      </div>
    );
  }
}

// export default ProtectionCart;
