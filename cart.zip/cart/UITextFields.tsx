import React, { Component } from "react";
import styles from "../../../style/cart.module.scss";

interface Props {
  label?: any;
  name?: string;
  type?: string;
  placeholder?: string;
  errorMessage?: string;
  value?: any;
  field?: any;
  onChange?: (e: { target: { name: string; value: string } }) => void;
  onBlur?: any;
  disabled?:any
  autoFocus?:any
  otpButtonText?:string
  onKeyPress?:any
  isRequired?:boolean
  id?:string
  maxLength?:number
}

const UITextFields = (props: Props) => {
  return (
  
    <div className={styles.singleFields}>
      <label>
        {props.label}
        {props.isRequired && <em>*</em>}
      </label>
      <input 
        onKeyPress={props.onKeyPress}
        className={props.errorMessage?styles.errorInput: styles.input}
        type={props.type}
        placeholder={props.placeholder}
        onBlur={props.onBlur}
        value={props.value}
        name={props.name}
        disabled={props.disabled}
        onChange={props.onChange}
       autoFocus={props.autoFocus}
       id={props.id}
       maxLength={props.maxLength}
      ></input>
      <p className={styles.errorMessage}>{props.errorMessage}</p>
    </div>
  );
};

export default UITextFields;
