import React, { useState } from "react";
// import styles from "../../style/cart.module.scss";
import styles from "../../../style/cart.module.scss";
// import TermsAndConditions from '../../../../components/cart/TermsAndConditions';
import TermsAndConditions from "../TermsAndConditions";
// import KeyboardArrowDownIcon from "@material-ui/icons/KeyboardArrowDown";

const TermsAndCondition = () => {
  const [isDisable,setIsDisable]=useState(true)
  return (
    <div className={styles.termsAndConditionContainer}>
      <div className={styles.termsAndCondition}>
        <TermsAndConditions content="For Annual plans, the device should be in working condition" />
        <TermsAndConditions content="For Comprehensive and Advanced AMC for AC,inspection will be conducted post-purchase and nearthe plan start date" />
        <TermsAndConditions content="Any spare part or gas charging (for AC) if needed during first visit/inspection the charges will be borne by the customer" />
        <TermsAndConditions
          content="By proceeding, you agree to the"
          terms="Terms of Service"
        />
        <div className={styles.paymentContainer}>
          <div className={styles.payment}>
            <button disabled={true}>PROCEED TO PAYMENT</button>
            <span>or</span>
            <span>PAY AFTER SERVICE</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsAndCondition;
