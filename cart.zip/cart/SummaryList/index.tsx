import React, { useState,useEffect } from "react";
import styles from "../../../../style/cart.module.scss";
import { formatNumber } from "../../../../../utils";
import { getPhoneCookie } from "../../../../../utils/cartV2/index";
import Cookies from 'js-cookie'
interface Props {
  cart?: any;
  setOtpVerificationAccordion?: any;
  applyDiscount?:any,
  removeDiscount?:any,
}

const SummaryList = (props: Props) => {
  const [couponCode, setCouponCode] = useState("");
  const [couponCodeError, setCouponCodeError] = useState("");
  const [isCouponCodeError, setIsCouponError] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCouponCode(e.target.value);
    setCouponCodeError("");
  };
  const applyDiscount = () => {
    props.applyDiscount({
      application: "website",
      data: {
        discount_code: couponCode,
        channel_name: "website",
        token_id: props.cart.token_id,
      },
    });
    couponCode == "" ? setCouponCodeError("Please enter a discount code!") : "";
  };
  const removeDiscount = () => {
    setIsCouponError(false);
    setCouponCode("");
    props.removeDiscount({
      application: "website",
      data: {
        token_id: props.cart.token_id,
      },
    });
  };

  function scrollToTargetAdjusted(){
    var element = document.querySelector('#otpVerificationAccordion');
    var headerOffset = 100;
    var elementPosition = element.getBoundingClientRect().top;
    var offsetPosition = elementPosition + window.pageYOffset - headerOffset;
  
    window.scrollTo({
         top: offsetPosition,
         behavior: "smooth"
    });
}

  const procedButton = () => {
    // Cookies.get('isAuthenticate')?
    // props.setOtpVerificationAccordion(false):props.setOtpVerificationAccordion(true)
    props.setOtpVerificationAccordion(true)
    scrollToTargetAdjusted()

    const a: any = document.getElementById(`inputmobile`);
      setTimeout(() => { a.focus() }, 500)
  };

  useEffect(() => {
    if (props.cart?.discount_message?.is_valid) {
      setCouponCodeError("");
      setIsCouponError(true);
    } else {
      setCouponCodeError(props.cart?.discount_message?.message);
    }
  }, [props.cart]);
  return (
    <>
      <div className={styles.cartSummaryBottomAction}>
        {!isCouponCodeError ? (
          <div className={styles.coupon}>
            <div className={styles.couponCode}>
              <input
                type="text"
                placeholder="Have a coupon code ?"
                maxLength={16}
                value={couponCode}
                onChange={(e) => handleChange(e)}
                
              ></input>
              <button onClick={applyDiscount}>APPLY</button>
            </div>
            <div>
              <p style={{ marginTop: "5px" }}>{couponCodeError}</p>
            </div>
          </div>
        ) : (
          <div className={styles.couponApplied}>
            <div>
              <img src=""></img>
            </div>
            <div>
              <span>Yoy ! you save &#8377; 50</span>
              <p>Coupon Applied</p>
            </div>
            <div className={styles.removeCoupon} onClick={removeDiscount}>
              x
            </div>
          </div>
        )}
      </div>

      <div className={styles.total_container}>
        <div className={styles.total}>
          <div className={styles.total_item_container}>
            <div className={styles.total_item}>
              <div className={styles.totalText}>
                <p>Total</p>
                <p className={styles.totalItems}>
                  {" "}
                  ({props.cart.items.length} items):
                </p>
              </div>
              <div>
                <p>(Incl. Tax)</p>
              </div>
            </div>
            <div className={styles.amount}>
              &#8377;{" "}
              {formatNumber(props.cart.amount).replace(
                formatNumber(props.cart.amount)[0],
                ""
              )}
            </div>
          </div>
          <div className={styles.proceedBtn}>
            <button onClick={procedButton}>PROCEED</button>
          </div>
        </div>
      </div>
    </>
  );
};

export default SummaryList;
