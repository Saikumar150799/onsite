import React from "react";
import styles from "../../../style/cart.module.scss";
import KeyboardArrowDownIcon from "@material-ui/icons/KeyboardArrowDown";
import SlotTiming from "./SlotTiming";

const SlotSelection = () => {
  return (
    <div className={styles.SlotSelectionContainer}>
      <p className={styles.heading}>
        Select your preferred slots for our technician to visit your home{" "}
      </p>
      <div className={styles.slots}>
        <div className={styles.slot_1}>
          <div className={styles.slotTitle}>Microwave</div>
          <div className={styles.slotDetails}>
            <div>Repair x 1</div>
            <div>
              <SlotTiming />
            </div>
          </div>
        </div>
        <div className={styles.slot_2}></div>
      </div>
    </div>
  );
};

export default SlotSelection;
