import React, { Component } from "react";
import styles from "../../../style/cart.module.scss";
import KeyboardArrowDownIcon from "@material-ui/icons/KeyboardArrowDown";
import fields from "../../../formFields/Fields";
import { PERSONAL_DETAILS_FIELDS } from "../../constants/Fields";
import validation from "common/validation/validation";
import UITextField from "./UITextFields";
import AgentPersonalDetails from "./AgentPersonalDetails";
import {
  getCustomerCookie,
  setCustomerCookie,
  setIsVerifyPersonalDetails,
  getIsVerifyPersonalDetails,
  setIsAuthenticate,
  getUserExist,
} from "../../../../utils/cartV2/index";
import Cookies from "js-cookie";
interface Props {
  setPaymentDetailsAccordion: any;
  setPersonalDetailsAccordion: any;
  customer: any;
  cart: any;
  serviceModalToggle: any;
  updateServiceable: any;
}
import {
  setCookie,
  getIsAuthenticate,
  setUserExist,
} from "../../../../utils/cartV2/index";
import ServiceablePopUp from "./ServiceablePopUp";
import { Serviceable } from "../../../../api/cart";
import { UpdateCustomerDetails } from "../../../../api/myaccount";
export default class PersonalDetails extends Component<Props> {
  state = {
    fields: PERSONAL_DETAILS_FIELDS,
    isButtonEnable: true,
    verify: false,
    IsValidPersonalDetails: false,
    name: "",
    email: "",
    address: "",
    city: "",
    pincode: "",
    isEditMode: false,
    showCity: false,
  };

  allFieldsIsValid = {};
  values = [];
  details = {};

  componentDidMount() {
    this.state.fields.forEach((field) => {
      field.name == "pincode" && field.value.length == 6
        ? Serviceable(this.props.cart.token_id, {
            application: "website",
            pincode: field.value,
          }).then((res) => {
            this.setState({ city: `${res?.data.city}, ${res?.data.state}` });
          })
        : "";

      if (getCustomerCookie()?.hasOwnProperty(field.name)) {
        field.value = getCustomerCookie()[field.name];
      } else if (
        getCustomerCookie()?.address_info?.hasOwnProperty(field.name)
      ) {
        field.value = getCustomerCookie().address_info[field.name];
      }
    });

    this.state.fields.forEach((field) => {
      if (field.value) {
        this.values.push(field.value);
      }
    });

    this.values.length >= 4
      ? this.setState({ IsValidPersonalDetails: true })
      : this.setState({ IsValidPersonalDetails: false });

    this.setState({
      city: `${getCustomerCookie()?.address_info?.city}, ${
        getCustomerCookie()?.address_info?.state
      }`,
    });
  }

  handleChange = (e, field) => {
    let { name, value } = e.target;
    this.state.fields.map((field) => {
      if (field.name === name) {
        field.value = value;
      }
    });

    if (name in this.allFieldsIsValid) {
      !validation(field).isValid
        ? (this.allFieldsIsValid[name] = "false")
        : (this.allFieldsIsValid[name] = "true");
    } else {
      validation(field).isValid ? (this.allFieldsIsValid[name] = "true") : null;
    }

    if (name == "pincode") {
      if (value.length == 6) {
        Serviceable(this.props.cart.token_id, {
          application: "website",
          pincode: value,
        }).then((res) => {
          this.props.updateServiceable(res?.data.serviceable, true);
          if (
            this.props.cart.items.filter((_item) => !_item.serviceable).length
          ) {
          } else {
            res?.data.city && res.data.state
              ? this.setState({ city: `${res?.data.city}, ${res?.data.state}` })
              : null;
          }
        });
      } else {
        this.setState({ city: "" });
      }
    }

    // if (
    //   Cookies.get("isAuthenticate") == "true" &&
    //   Object.values(this.allFieldsIsValid).every((field) => field === "true") &&
    //   Object.values(this.allFieldsIsValid).length > 2
    // ) {
    //   this.setState({ verify: true });
    //   setIsVerifyPersonalDetails(true);
    // } else if (
    //   Cookies.get("isAuthenticate") == "false" &&
    //   Object.values(this.allFieldsIsValid).every((field) => field === "true") &&
    //   Object.values(this.allFieldsIsValid).length > 4
    // ) {
    //   this.setState({ verify: true });
    //   setIsVerifyPersonalDetails(true);
    // } else {
    //   this.setState({ verify: false });
    //   setIsVerifyPersonalDetails(false);
    // }

    this.state.fields.forEach((field) => {
      if (this.details.hasOwnProperty(field.name)) {
        this.details[field.name] = field.value;
        if (field.name == "landmark") {
          field.value == "" ? delete this.details[field.name] : "";
        } else if (field.name == "city") {
          this.details[field.name] = this.state.city;
        }
      } else {
        field.name != "landmark"
          ? (this.details[field.name] = field.value)
          : null;
      }
    });

    field.errorMessage = "";
    this.setState({ fields: PERSONAL_DETAILS_FIELDS });

    // console.log("details", this.details, this.state.city);

    if (Object.values(this.details).every((val) => val) && field.isValid) {
      this.setState({ verify: true });
      // this.setState({ IsValidPersonalDetails: true })
    } else {
      this.setState({ verify: false });
      // this.setState({ IsValidPersonalDetails: false })
    }
  };

  handleBlur = (e, field) => {
    this.setState(validation(field));
  };

  handleEditPersonalDetails = () => {
    this.setState({ IsValidPersonalDetails: false });
  };

  handleEditMode = () => {
    this.setState({ isEditMode: true });
  };

  customer_personal_details = {};
  new_customer_personal_details = {};
  verifyPersonalDetails = () => {
    this.props.setPaymentDetailsAccordion(true);
    this.setState({ IsValidPersonalDetails: true });
    setIsAuthenticate(true);

    this.state.fields.forEach((field) => {
      for (let [key, value] of Object.entries(getCustomerCookie())) {
        if (this.customer_personal_details.hasOwnProperty(key)) {
          this.customer_personal_details[field.name] = field.value;
          field.name == "city"
            ? (this.customer_personal_details[field.name] = this.state.city)
            : null;
        } else {
          this.customer_personal_details[key] = value;
        }
      }
      field.name == "city"
        ? (this.new_customer_personal_details[field.name] = this.state.city)
        : (this.new_customer_personal_details[field.name] = field.value);
    });
    // UpdateCustomerDetails({...this.customer_personal_details,}).then((res)=>{
    //   console.log("sucess",res)
    // })
    getUserExist()
      ? setCustomerCookie(this.customer_personal_details)
      : setCustomerCookie(this.new_customer_personal_details);
  };

  render() {
    return (
      <div className={styles.PersonalDetails}>
        {!this.state.IsValidPersonalDetails ? (
          <>
            <div className={styles.fields}>
              {PERSONAL_DETAILS_FIELDS.map((field) => {
                return (
                  <UITextField
                    type={field.type}
                    isRequired={field.isRequired}
                    onChange={(e) => this.handleChange(e, field)}
                    onBlur={(e) => this.handleBlur(e, field)}
                    placeholder={field.placeholder}
                    value={field.name == "city" ? this.state.city : field.value}
                    label={field.label}
                    name={field.name}
                    field={field}
                    errorMessage={field.errorMessage}
                    disabled={field.name == "city" ? true : ""}
                    maxLength={
                      field.rules.find((val) => val.name == "maxLength")
                        ?.maxLength
                    }
                  />
                );
              })}
            </div>
            <div className={styles.confirmBtn}>
              <button
                disabled={this.state.verify ? false : true}
                onClick={() => this.verifyPersonalDetails()}
              >
                {!this.state.isEditMode ? "CONFIRM" : "UPDATE"}
              </button>
            </div>
          </>
        ) : (
          <AgentPersonalDetails
            fields={this.state.fields}
            IsValidPersonalDetails={this.handleEditPersonalDetails}
            isEditMode={this.handleEditMode}
            city={this.state.city}
          />
        )}

        {this.props.cart.serviceablePopup && (
          <ServiceablePopUp
            cart={this.props.cart}
            serviceModalToggle={this.props.serviceModalToggle}
          />
        )}
      </div>
    );
  }
}

// export default PersonalDetails;
