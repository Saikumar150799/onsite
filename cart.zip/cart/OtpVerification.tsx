import React, { Component } from "react";
import styles from "../../../style/cart.module.scss";
import { OTP_FIELDS } from "../../constants/Fields";
import UIAccordion from "@/components/cart/UIAccordion";
import validation from "common/validation/validation";
import UITextField from "./UITextFields";
import { connect } from "react-redux";
import { SendOTP, VerifyOTP } from "../../../../api/cart";
import { getParameterByName } from "../../../../utils/cart";
import Cookies from "js-cookie";
import { SignIn } from "../../../../api/myaccount";
import {
  setPhoneCookie,
  getPhoneCookie,
  setIsAuthenticate,
  setCustomerCookie,
  setUserExist
} from "../../../../utils/cartV2/index";
import { Phone } from "@material-ui/icons";
import {updateMobileNumber, updateTokenId} from "../../../../redux/actions/selfserveActions"
import store from '../../../../redux'
import { setCustomerDetailsRedux } from "../../../../redux/actions/cartActions";
interface Props {
  setOtpVerificationAccordion?: any;
  otpVerificationAccordion?: any;
  setPersonalDetailsAccordion?: any;
  cart?: any;
  setCustomerDetailsRedux?:any;
  customer?:any;
}

class OtpVerification extends Component<Props> {
  state = {
    fields: OTP_FIELDS,
    isVerify: true,
    isButtonEnable: false,
    otpButtonText: "SEND OTP",
    disabled: true,
    autoFocus: true,
    buttonDisable: true,
    resendOtp: false,
    count: 30,
    phoneNumber: "",
    otp: "",
    otpCodeVerify: false,
    haswhatsappConsent: true,
    isPhoneExist: false,
    checked: true,
    
  };

  handleChange = (e, field) => {
    if (!isNaN(e.target.value)) {
      const { name, value } = e.target;
      this.state.fields.map((field) => {
        if (field.name === name) {
          field.value = value;
        }
      });
      field.errorMessage = "";

      name == "mobile" && value.length == 10
        ? this.setState({ otpButtonText: "SEND OTP" })
        : "";
      // && value!=getPhoneCookie("phoneNumber")
      if (
        name == "mobile" &&
        value.length == 10 &&
        value!=getPhoneCookie("phoneNumber")
        // value != JSON.parse(Cookies.get('customer_personal_details'))['phone']
      ) {
        this.setState({ phoneNumber: field.value });
        this.setState({ isButtonEnable: true });
      } else if (name == "otp" && value.length === 4) {
        this.setState({ otp: field.value });
        this.setState({ isButtonEnable: true });
      } else {
        this.setState({ isButtonEnable: false });
      }
    }
    this.setState({ fields: OTP_FIELDS });
  };

  handleBlur = (e, field) => {
    if (e.target.value == getPhoneCookie("phoneNumber")) {
      this.props.setOtpVerificationAccordion(false);
    }
    this.setState(validation(field));
  };

  // sending OTP
  sendOTP = () => {
    SendOTP({
      application: "website",
      data: {
        phone: this.state.phoneNumber,
        token_id: this.props.cart.token_id,
        type: "customer-login",
        template: "otp_send",
        force: true,
      },
    })
      .then((res) => {
        this.setState({ isPhoneExist: res?.data.exists });
        res?.data.exists ? this.setState({ isLogin: true }) : null;
        if (res?.data.status) {
          this.setState({ haswhatsappConsent: res.data.wa_subscribed });
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  sendOtp = () => {
    this.setState({ disabled: false });
    this.setState({ isButtonEnable: false });
    this.setState({ resendOtp: true });
    this.setState({ otpButtonText: "VERIFY OTP" });

    setInterval(() => {
      this.setState({ count: this.state.count - 1 });
    }, 1000);

    this.sendOTP(); //sending OTP
  };

  validateOTP = () => {
    if (this.state.isPhoneExist) {
      SignIn({
        phone: this.state.phoneNumber,
        otp: this.state.otp,
        cart_id: this.props.cart.token_id,
      })
        .then((res) => {
          this.props.setOtpVerificationAccordion(false);
          this.props.setPersonalDetailsAccordion(true);
          setPhoneCookie("phoneNumber", this.state.phoneNumber);
          setUserExist(true)
          this.setState({ disabled: true });
          this.setState({ isButtonEnable: false });
          this.setState({ otpCodeVerify: false });

          
          let personalDetail={
            name:res?.data.name,
            email:res?.data.email,
            phone:res?.data.phone,
          }
          if(res?.data.address_info){
            personalDetail={...personalDetail,...res.data.address_info}
          }
          setCustomerCookie(res?.data);
          setIsAuthenticate(true);
          // this.props.setCustomerDetailsRedux(personalDetail)
          // store.dispatch(updateMobileNumber(res?.data.phone))
          // store.dispatch(updateTokenId(res?.data.token_id))
        })
        .catch((err) => console.log(err));
    } else {
      
      setCustomerCookie(null);
      setIsAuthenticate(false);

      VerifyOTP({
        application: "website",
        data: {
          phone: this.state.phoneNumber,
          token_id: this.props.cart.token_id,
          type: "customer-login",
          otp: this.state.otp,
          // gclid: getParameterByName('gclid'),
          trigger_abandoned_callback: true,
          // has_whatsapp_opt_in:this.state.haswhatsappConsent
        },
      })
        .then((res) => {
          // console.log("DATA",res?.data)
          setUserExist(false)
          setPhoneCookie("phoneNumber", this.state.phoneNumber);
          this.setState({ disabled: true });
          this.setState({ isButtonEnable: false });
          this.props.setOtpVerificationAccordion(false);
          // if the entered otp is correct collapse the accordion
          this.setState({ otpCodeVerify: false });
          this.props.setPersonalDetailsAccordion(true);
          setIsAuthenticate(true);
          setCustomerCookie("")
        })
        .catch((err) => {
          this.setState({ otpCodeVerify: true });
        });
    }
  };

  resendOTP = () => {
    this.setState({ count: 30 });
    this.sendOTP();
  };

  handleEnter = (e) => {
    var a;
    if (e.key) {
      a = e.key;
    } else {
      a = e.which || e.keyCode;
    }
    if (a === "Enter" || a === 13) {
      this.state.otpButtonText == "SEND OTP" && this.state.isButtonEnable
        ? this.sendOtp()
        : this.validateOTP();

      const a: any = document.getElementById(`inputotp`);
      console.log("element",a)
      setTimeout(() => {
        a.focus();
      }, 500);
    }
  };

  componentDidMount() {
    this.state.fields.forEach((field) => {
      if (field.name == "mobile") {
          field.value =getPhoneCookie("phoneNumber") ;
         }
    });

  }

  render() {
    return (
      <div className={styles.otpContainer}>
        <div className={styles.fields}>
          {OTP_FIELDS.map((field) => {
            return (
              <>
                <UITextField
                  onKeyPress={(e) => this.handleEnter(e)}
                  type={field.type}
                  label={field.label}
                  placeholder={field.placeholder}
                  onChange={(e) => this.handleChange(e, field)}
                  onBlur={(e) => this.handleBlur(e, field)}
                  value={field.value}
                  name={field.name}
                  field={field}
                  isRequired={field.isRequired}
                  errorMessage={
                    !this.state.otpCodeVerify
                      ? field.errorMessage
                      : field.name == "otp"
                      ? "Incorrect OTP"
                      : ""
                  }
                  otpButtonText={this.state.otpButtonText}
                  disabled={field.name=='otp'? this.state.disabled:""}
                  autoFocus={true}
                  id={`input${field.name}`}
                  maxLength={field.rules.find((val)=>val.name=='maxLength')?.maxLength}
                  
                />
                {!this.state.haswhatsappConsent ? (
                  <div className={styles.agreeWhatsappContainer}>
                    {field.name == "mobile" ? (
                      <div className={styles.agreeWhatsapp}>
                        <input
                          type="checkbox"
                          defaultChecked={this.state.checked}
                        ></input>
                        <pre>
                          I agree to receive updates on
                          <img
                            src="https://logodownload.org/wp-content/uploads/2015/04/whatsapp-logo-1.png"
                            width="18px"
                            height="18px"
                          ></img>
                          Whatsapp
                        </pre>
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                ) : (
                  ""
                )}
              </>
            );
          })}
          <div className={styles.otpBtn}>
            <button
              className={styles.sendOtpBtn}
              disabled={this.state.isButtonEnable ? false : true}
              // style={{ opacity: this.state.isButtonEnable ? "1" : "0.3" }}
              onClick={() =>
                this.state.otpButtonText == "SEND OTP" &&
                this.state.isButtonEnable
                  ? this.sendOtp()
                  : this.validateOTP()
              }
            >
              {this.state.otpButtonText}
            </button>
            {this.state.resendOtp ? (
              <div>
                {this.state.count > 0 ? (
                  <>
                    <span>OTP SENT</span>
                    <p>Resend OTP after {this.state.count} seconds</p>
                  </>
                ) : (
                  <p
                    style={{
                      height: "80%",
                      display: "grid",
                      placeItems: "center",
                      cursor: "pointer",
                    }}
                    onClick={this.resendOTP}
                  >
                    Resend OTP
                  </p>
                )}
              </div>
            ) : (
              ""
            )}
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state: any) => {
  return {
    cart: state.cart,
    customer: state.customerReducer,
  };
};

export default OtpVerification;
