import React from "react";
import styles from "../../../style/cart.module.scss";

const Banner = () => {
  return (
    <div className={styles.banner}>
      <div className={styles.cartProgess}>
          <span>Your Cart</span>
          <span>Payment Details</span>
          <span>Order Confirmation</span>
      </div>
    </div>
  );
};

export default Banner;
